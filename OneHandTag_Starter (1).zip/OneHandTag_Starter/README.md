# ONEHAND TAG — Unity VR Starter Kit

An original Gorilla-Tag-style VR prototype starter with:
- One-controller arm-swing locomotion (left or right hand selectable)
- A spectator/casting camera output
- Server-side movement validation hooks for Unity Netcode for GameObjects
- A security checklist and setup guide

## Important scope
This is source code, not a compiled Quest APK and not a complete finished game. A Unity project must be opened and built in a compatible development environment before it can run on Meta Quest. It uses original implementations and does not include Gorilla Tag proprietary code, maps, or assets.

## Dependencies
- Unity version compatible with your chosen Meta XR / OpenXR setup
- XR Plug-in Management + OpenXR, configured for Meta Quest
- Unity Netcode for GameObjects (NGO) for multiplayer anti-cheat scripts
- A network transport such as Unity Transport

The locomotion and casting scripts can be tested without NGO. The server validation script requires NGO.

## Suggested scene setup
1. Create a Unity 3D project and configure OpenXR for Quest.
2. Add an XR Origin / camera rig from your chosen XR setup.
3. Add a Rigidbody to the player root; freeze rotation and tune mass/drag.
4. Add colliders to the player body/hands and to the environment.
5. Add `OneHandArmSwingLocomotion` to the player root. Assign the Rigidbody, head transform, and hand transform if desired. Set `Active Hand` to Right or Left.
6. Create a child object for a spectator camera, add a Camera and RenderTexture, then assign both to `CastingViewController`. Put the RenderTexture on a UI RawImage or a monitor in the world.
7. For multiplayer, install NGO. Put `ServerMovementAntiCheat` on the network player prefab and assign the Rigidbody and body collider. Ensure the player movement object is server-authoritative and that clients cannot write authoritative position values.
8. Tune thresholds in a private test session before exposing the game publicly.

## Anti-cheat notes
No client-side anti-cheat is unbreakable. The included validator is a starting layer, not a guarantee. The server should own authoritative position/state, validate movement against surfaces and game rules, rate-limit RPCs, and log suspicious events. Do not permanently ban on a single noisy sample; use repeated evidence and review.

## Casting notes
`CastingViewController` renders a spectator camera into a RenderTexture for an in-game display or streaming overlay. Actual Quest-to-TV/phone screen casting is provided by the Quest operating system and is not enabled by an in-game script alone.


## Added camera and quality pass
- `OverdriveCameraController.cs`: Follow, Orbit, and Free camera modes, zoom, right-controller input, RenderTexture output.
- `QUALITY_AND_SECURITY.md`: visual polish, Quest performance, comfort, and anti-cheat hardening checklist.

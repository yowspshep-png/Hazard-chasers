# Quality & polish targets

This folder is a foundation, not a finished commercial game. Use these targets to move toward a polished Quest experience.

## Visual direction
- Original forest arena with layered depth: near gameplay landmarks, mid-distance paths, and a lightweight far background.
- Use authored meshes/materials and readable silhouettes; avoid placeholder cubes and floating UI labels.
- Use baked lighting where possible, subtle fog, restrained bloom, and high-contrast UI.
- Use consistent material roughness; avoid excessive emissive glow.
- Keep menu text legible at VR distances and provide a comfortable panel size.

## Quest performance
- Profile on the actual target headset.
- Prefer baked lighting, GPU instancing, LOD groups, occlusion culling, and pooled effects.
- Avoid expensive real-time shadows on many moving objects.
- Use fixed foveated rendering / XR performance settings supported by the chosen Meta XR SDK.
- Keep physics interactions simple and avoid unnecessary per-frame allocations.
- Use object pooling for particles, hit effects, and tag feedback.

## Comfort and accessibility
- Offer left/right hand selection even if the default is right-handed.
- Provide a seated/comfort option, recenter control, snap-turn option, and adjustable movement sensitivity.
- Keep camera shake off by default and avoid forced camera movement.
- Make camera mode changes visible with a small, unobtrusive status indicator.

## Anti-cheat production checklist
- Server-authoritative movement and match state.
- Validate movement against allowed locomotion and collision contacts, not only a fixed speed limit.
- Server-side tag range, line-of-sight, cooldown, inventory, currency, and room-state validation.
- Rate-limit RPCs and reject invalid sequences.
- Log evidence and use multiple signals; do not permanently ban on one sample.
- Test tracking loss, lag spikes, low frame rate, and normal fast arm swings.
- Keep the client as presentation/input; never trust client-supplied awards, prices, or tag outcomes.

## Camera feature notes
`OverdriveCameraController` is an original in-game spectator camera with Follow, Orbit, and Free modes, zoom, and right-controller input. It outputs to a RenderTexture, which can be shown on an in-game monitor or UI. Actual Meta Quest system casting is controlled through the headset's operating system and is separate.

# Scene setup quick guide

## One-hand locomotion
- Add `OneHandArmSwingLocomotion` to the player Rigidbody root.
- Assign `trackedHandOverride` to the transform of the chosen controller's tracked hand. The script's `activeHand` is a preference marker; the rig-specific hand transform should be assigned because XR runtimes expose tracking differently.
- Set the player's pushable layer mask to the layers that represent solid world geometry.
- Ensure the hand visuals/colliders follow the tracked hand and do not collide with the player body.
- Test slowly and tune `handReach`, `pushMultiplier`, `maxSpeed`, and `jumpImpulse`.

## Casting preview
- Create a RenderTexture asset.
- Assign it to `outputTexture` and `spectatorCamera`.
- Put the texture on a UI RawImage or a material on a monitor screen.
- Assign the player/head transform as `target`.
- Actual Quest casting to a phone or TV is started through the Quest system UI.

## Multiplayer anti-cheat
- Install Unity Netcode for GameObjects.
- Add `NetworkObject` to the player prefab and add `ServerMovementAntiCheat`.
- Configure server-authoritative network transform/movement. Do not let client-owned transform replication override server corrections.
- Tune thresholds in a private session. Arm-swing VR movement can have brief spikes, so do not use the starter thresholds as final production values.

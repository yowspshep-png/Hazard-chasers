# Anti-cheat hardening checklist

The sample `ServerMovementAntiCheat` is only a first layer. For a serious public multiplayer game:

1. **Server authority:** Server owns canonical player positions, match state, tags, inventory, and currency. Never trust a client-reported result.
2. **Validate actions:** Validate tag distance, cooldowns, line of sight, item ownership, purchases, and round transitions on the server.
3. **Movement model:** Compare movement with the allowed locomotion model and collision contacts. Allow legitimate wall pushes, climbing, knockback, and lag compensation.
4. **Rate limits:** Rate-limit every client RPC and reject malformed or out-of-order requests.
5. **No client-side secrets:** Anything shipped to a player can be inspected or modified. Keep authority and economy decisions server-side.
6. **Detection and response:** Log evidence; use multiple signals and thresholds. Prefer correction or temporary restrictions before permanent bans.
7. **Replay/testing:** Test low FPS, network jitter, tracking loss, recentering, and normal high-speed play to reduce false positives.
8. **Secure economy:** Server validates every currency award and purchase. Never accept arbitrary client-supplied prices or balances.
9. **Privacy:** Do not collect unnecessary personal information or secretly scan unrelated device files.
10. **Operational controls:** Provide an appeal process and review logs before severe penalties.

No anti-cheat is perfect, especially if the client owns its own simulation. Strong enforcement depends on a server-authoritative architecture and careful tuning.

using UnityEngine;
using UnityEngine.XR;

/// <summary>
/// Small original arm-swing locomotion starter for a VR prototype.
/// Attach to the Rigidbody player root. It reads one controller only.
/// Requires colliders on the tracked hand and world geometry.
/// This is intentionally a starter implementation; tune physics in your project.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
public class OneHandArmSwingLocomotion : MonoBehaviour
{
    public enum HandChoice { Left, Right }

    [Header("One-hand control")]
    public HandChoice activeHand = HandChoice.Right;
    public Transform head;
    public Transform trackedHandOverride;
    public LayerMask pushableLayers = ~0;

    [Header("Movement tuning")]
    [Min(0.1f)] public float handReach = 0.32f;
    [Min(0f)] public float pushMultiplier = 1.15f;
    [Min(0f)] public float maxSpeed = 7.5f;
    [Min(0f)] public float jumpImpulse = 1.0f;
    [Min(0f)] public float groundProbeDistance = 0.18f;
    [Min(0f)] public float inputSmoothing = 18f;

    Rigidbody body;
    Vector3 previousHandPosition;
    Vector3 smoothedVelocity;
    bool wasTouching;
    bool initialized;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.freezeRotation = true;
        body.interpolation = RigidbodyInterpolation.Interpolate;
    }

    void FixedUpdate()
    {
        Transform hand = trackedHandOverride != null ? trackedHandOverride : ResolveHand();
        if (hand == null) return;

        Vector3 handPosition = hand.position;
        if (!initialized)
        {
            previousHandPosition = handPosition;
            initialized = true;
            return;
        }

        Vector3 handDelta = handPosition - previousHandPosition;
        previousHandPosition = handPosition;

        bool touching = Physics.CheckSphere(handPosition, handReach, pushableLayers, QueryTriggerInteraction.Ignore);
        if (touching)
        {
            // Moving the hand backward against a surface should move the body forward.
            Vector3 desired = -handDelta / Mathf.Max(Time.fixedDeltaTime, 0.001f);
            desired.y = Mathf.Clamp(desired.y, -maxSpeed, maxSpeed);
            desired = Vector3.ClampMagnitude(desired, maxSpeed);
            smoothedVelocity = Vector3.Lerp(smoothedVelocity, desired, 1f - Mathf.Exp(-inputSmoothing * Time.fixedDeltaTime));

            Vector3 horizontal = Vector3.ProjectOnPlane(smoothedVelocity, Vector3.up);
            body.AddForce(horizontal * pushMultiplier, ForceMode.Acceleration);

            if (!wasTouching && IsGrounded() && desired.y > 0.45f)
                body.AddForce(Vector3.up * jumpImpulse, ForceMode.Impulse);
        }
        else
        {
            smoothedVelocity = Vector3.Lerp(smoothedVelocity, Vector3.zero, 1f - Mathf.Exp(-inputSmoothing * Time.fixedDeltaTime));
        }

        Vector3 horizontalVelocity = Vector3.ProjectOnPlane(body.velocity, Vector3.up);
        if (horizontalVelocity.magnitude > maxSpeed)
            body.velocity = Vector3.ClampMagnitude(horizontalVelocity, maxSpeed) + Vector3.up * body.velocity.y;

        wasTouching = touching;
    }

    Transform ResolveHand()
    {
        XRNode node = activeHand == HandChoice.Right ? XRNode.RightHand : XRNode.LeftHand;
        InputDevice device = InputDevices.GetDeviceAtXRNode(node);
        if (!device.isValid) return null;

        // XR InputDevices does not provide a Transform. Use an assigned tracked hand transform
        // from your XR rig for reliable world-space position tracking.
        return null;
    }

    bool IsGrounded()
    {
        Vector3 origin = transform.position + Vector3.up * 0.08f;
        return Physics.SphereCast(origin, 0.18f, Vector3.down, out _, groundProbeDistance + 0.08f,
            pushableLayers, QueryTriggerInteraction.Ignore);
    }

    void OnDrawGizmosSelected()
    {
        Transform hand = trackedHandOverride;
        if (hand == null) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(hand.position, handReach);
    }
}

using UnityEngine;
using UnityEngine.XR;

/// <summary>
/// Original spectator camera controller inspired by common VR camera tools.
/// Supports follow/orbit and free-camera modes, zoom, and right-controller input.
/// Assign a tracked right-hand transform when available for a reliable controller anchor.
/// This is an in-game camera system, not a patch for another game's mod loader.
/// </summary>
public class OverdriveCameraController : MonoBehaviour
{
    public enum CameraMode { Follow, Orbit, Free }

    [Header("References")]
    public Camera targetCamera;
    public Transform target;
    public Transform rightHandAnchor;
    public RenderTexture outputTexture;

    [Header("Mode")]
    public CameraMode mode = CameraMode.Follow;
    public bool rightControllerInput = true;
    public bool startEnabled = false;

    [Header("Follow / orbit")]
    public Vector3 followOffset = new Vector3(0f, 2.1f, -4.8f);
    [Min(0.1f)] public float followSmooth = 6f;
    [Min(0.1f)] public float rotationSmooth = 7f;
    [Min(10f)] public float orbitSensitivity = 100f;
    [Min(0f)] public float orbitDistance = 5f;
    [Min(0.1f)] public float minZoom = 1.5f;
    [Min(0.1f)] public float maxZoom = 12f;

    [Header("Free camera")]
    [Min(0.1f)] public float freeMoveSpeed = 3f;
    [Min(0.1f)] public float fastMoveMultiplier = 2.5f;
    [Min(10f)] public float freeLookSensitivity = 90f;

    public bool IsEnabled { get; private set; }
    public CameraMode CurrentMode => mode;

    float yaw;
    float pitch = 12f;
    float distance;
    Vector3 freeVelocity;

    void Awake()
    {
        if (targetCamera == null) targetCamera = GetComponent<Camera>();
        distance = Mathf.Clamp(orbitDistance, minZoom, maxZoom);
        if (targetCamera != null && outputTexture != null)
            targetCamera.targetTexture = outputTexture;
    }

    void Start() => SetEnabled(startEnabled);

    void LateUpdate()
    {
        if (!IsEnabled || targetCamera == null) return;

        Vector2 stick = Vector2.zero;
        Vector2 moveStick = Vector2.zero;
        bool fast = false;
        bool toggleMode = false;
        bool zoomIn = false;
        bool zoomOut = false;

        if (rightControllerInput)
            ReadRightController(out stick, out moveStick, out fast, out toggleMode, out zoomIn, out zoomOut);

        if (toggleMode)
            mode = (CameraMode)(((int)mode + 1) % 3);

        if (zoomIn) distance = Mathf.Clamp(distance - 0.15f, minZoom, maxZoom);
        if (zoomOut) distance = Mathf.Clamp(distance + 0.15f, minZoom, maxZoom);

        switch (mode)
        {
            case CameraMode.Follow:
                UpdateFollow();
                break;
            case CameraMode.Orbit:
                UpdateOrbit(stick);
                break;
            case CameraMode.Free:
                UpdateFree(stick, moveStick, fast);
                break;
        }
    }

    public void SetEnabled(bool enabled)
    {
        IsEnabled = enabled;
        if (targetCamera != null)
        {
            targetCamera.enabled = enabled;
            if (enabled && outputTexture != null)
                targetCamera.targetTexture = outputTexture;
        }
    }

    public void ToggleEnabled() => SetEnabled(!IsEnabled);

    public void SetMode(CameraMode newMode) => mode = newMode;

    public void SetZoom(float value) => distance = Mathf.Clamp(value, minZoom, maxZoom);

    void UpdateFollow()
    {
        if (target == null) return;
        Vector3 desired = target.TransformPoint(followOffset);
        targetCamera.transform.position = Vector3.Lerp(targetCamera.transform.position, desired,
            1f - Mathf.Exp(-followSmooth * Time.deltaTime));
        Vector3 lookPoint = target.position + Vector3.up * 1.15f;
        Quaternion desiredRot = Quaternion.LookRotation(lookPoint - targetCamera.transform.position, Vector3.up);
        targetCamera.transform.rotation = Quaternion.Slerp(targetCamera.transform.rotation, desiredRot,
            1f - Mathf.Exp(-rotationSmooth * Time.deltaTime));
    }

    void UpdateOrbit(Vector2 look)
    {
        if (target == null) return;
        yaw += look.x * orbitSensitivity * Time.deltaTime;
        pitch = Mathf.Clamp(pitch - look.y * orbitSensitivity * Time.deltaTime, -20f, 75f);
        Quaternion orbitRot = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 focus = target.position + Vector3.up * 1.15f;
        Vector3 desired = focus - (orbitRot * Vector3.forward * distance);
        targetCamera.transform.position = Vector3.Lerp(targetCamera.transform.position, desired,
            1f - Mathf.Exp(-followSmooth * Time.deltaTime));
        targetCamera.transform.rotation = Quaternion.Slerp(targetCamera.transform.rotation,
            Quaternion.LookRotation(focus - targetCamera.transform.position, Vector3.up),
            1f - Mathf.Exp(-rotationSmooth * Time.deltaTime));
    }

    void UpdateFree(Vector2 look, Vector2 move, bool fast)
    {
        Transform basis = rightHandAnchor != null ? rightHandAnchor : targetCamera.transform;
        yaw += look.x * freeLookSensitivity * Time.deltaTime;
        pitch = Mathf.Clamp(pitch - look.y * freeLookSensitivity * Time.deltaTime, -85f, 85f);
        targetCamera.transform.rotation = Quaternion.Euler(pitch, yaw, 0f);

        float speed = freeMoveSpeed * (fast ? fastMoveMultiplier : 1f);
        Vector3 direction = targetCamera.transform.forward * move.y + targetCamera.transform.right * move.x;
        freeVelocity = Vector3.ClampMagnitude(direction, 1f) * speed;
        targetCamera.transform.position += freeVelocity * Time.deltaTime;
    }

    void ReadRightController(out Vector2 look, out Vector2 move, out bool fast,
        out bool toggleMode, out bool zoomIn, out bool zoomOut)
    {
        look = Vector2.zero;
        move = Vector2.zero;
        fast = toggleMode = zoomIn = zoomOut = false;

        InputDevice device = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        if (!device.isValid) return;

        if (device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 axis))
        {
            look = axis;
            move = axis;
        }

        device.TryGetFeatureValue(CommonUsages.gripButton, out fast);
        device.TryGetFeatureValue(CommonUsages.primaryButton, out toggleMode);
        device.TryGetFeatureValue(CommonUsages.secondaryButton, out zoomIn);
        device.TryGetFeatureValue(CommonUsages.triggerButton, out zoomOut);
    }
}

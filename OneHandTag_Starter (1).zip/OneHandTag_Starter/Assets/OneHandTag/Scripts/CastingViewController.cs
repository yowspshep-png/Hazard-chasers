using UnityEngine;

/// <summary>
/// Renders a secondary spectator camera to a RenderTexture for an in-game monitor,
/// local preview, or streaming overlay. OS-level Quest casting is separate.
/// </summary>
public class CastingViewController : MonoBehaviour
{
    [Header("Output")]
    public Camera spectatorCamera;
    public RenderTexture outputTexture;

    [Header("Follow target")]
    public Transform target;
    public Vector3 followOffset = new Vector3(0f, 2.2f, -4.5f);
    [Min(0.1f)] public float positionSmooth = 5f;
    [Min(0.1f)] public float rotationSmooth = 5f;
    public bool startEnabled = true;

    public bool IsCastingViewEnabled { get; private set; }

    void Start()
    {
        if (spectatorCamera != null && outputTexture != null)
            spectatorCamera.targetTexture = outputTexture;
        SetEnabled(startEnabled);
    }

    void LateUpdate()
    {
        if (!IsCastingViewEnabled || spectatorCamera == null || target == null) return;

        Vector3 desiredPosition = target.TransformPoint(followOffset);
        spectatorCamera.transform.position = Vector3.Lerp(
            spectatorCamera.transform.position, desiredPosition,
            1f - Mathf.Exp(-positionSmooth * Time.deltaTime));

        Vector3 lookPoint = target.position + Vector3.up * 1.1f;
        Quaternion desiredRotation = Quaternion.LookRotation(lookPoint - spectatorCamera.transform.position, Vector3.up);
        spectatorCamera.transform.rotation = Quaternion.Slerp(
            spectatorCamera.transform.rotation, desiredRotation,
            1f - Mathf.Exp(-rotationSmooth * Time.deltaTime));
    }

    public void Toggle() => SetEnabled(!IsCastingViewEnabled);

    public void SetEnabled(bool enabled)
    {
        IsCastingViewEnabled = enabled;
        if (spectatorCamera != null)
        {
            spectatorCamera.enabled = enabled;
            if (enabled && outputTexture != null)
                spectatorCamera.targetTexture = outputTexture;
        }
    }
}

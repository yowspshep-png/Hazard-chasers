using UnityEngine;
using Unity.Netcode;

/// <summary>
/// Server-side movement sanity checks for a networked player.
/// Attach to a NetworkObject player prefab. Server must be authoritative for movement.
/// This component flags suspicious samples and can return a player to the last accepted position.
/// Tune values for your actual locomotion; false positives are possible.
/// </summary>
[RequireComponent(typeof(NetworkObject))]
public class ServerMovementAntiCheat : NetworkBehaviour
{
    [Header("References")]
    public Rigidbody playerBody;
    public Collider playerCollider;

    [Header("Validation thresholds")]
    [Min(1f)] public float maxHorizontalSpeed = 9f;
    [Min(1f)] public float maxVerticalSpeed = 16f;
    [Min(0.5f)] public float maxSingleStepDistance = 1.35f;
    [Min(1)] public int strikesBeforeCorrection = 3;
    [Min(0.1f)] public float sampleInterval = 0.15f;
    [Min(0.1f)] public float correctionCooldown = 1.0f;

    [Header("Optional event")]
    public bool logSuspiciousSamples = true;

    Vector3 lastAcceptedPosition;
    float sampleTimer;
    float lastCorrectionTime = -999f;
    int strikes;

    public override void OnNetworkSpawn()
    {
        if (!IsServer) return;
        lastAcceptedPosition = transform.position;
        if (playerBody == null) playerBody = GetComponent<Rigidbody>();
        if (playerCollider == null) playerCollider = GetComponent<Collider>();
    }

    void FixedUpdate()
    {
        if (!IsSpawned || !IsServer) return;

        sampleTimer += Time.fixedDeltaTime;
        if (sampleTimer < sampleInterval) return;
        float dt = sampleTimer;
        sampleTimer = 0f;

        Vector3 current = transform.position;
        Vector3 delta = current - lastAcceptedPosition;
        float horizontalSpeed = new Vector2(delta.x, delta.z).magnitude / Mathf.Max(dt, 0.001f);
        float verticalSpeed = Mathf.Abs(delta.y) / Mathf.Max(dt, 0.001f);
        float stepDistance = delta.magnitude;

        bool suspicious = horizontalSpeed > maxHorizontalSpeed ||
                          verticalSpeed > maxVerticalSpeed ||
                          stepDistance > maxSingleStepDistance;

        if (suspicious)
        {
            strikes++;
            if (logSuspiciousSamples)
                Debug.LogWarning($"[AntiCheat] Suspicious movement sample on client {OwnerClientId}. " +
                                 $"H={horizontalSpeed:F1}, V={verticalSpeed:F1}, Step={stepDistance:F2}, Strikes={strikes}");

            if (strikes >= strikesBeforeCorrection && Time.time - lastCorrectionTime >= correctionCooldown)
            {
                CorrectToLastAccepted();
                strikes = 0;
                lastCorrectionTime = Time.time;
            }
        }
        else
        {
            // Slowly forgive isolated noisy samples.
            strikes = Mathf.Max(0, strikes - 1);
            lastAcceptedPosition = current;
        }
    }

    void CorrectToLastAccepted()
    {
        if (playerBody != null)
        {
            playerBody.position = lastAcceptedPosition;
            playerBody.velocity = Vector3.zero;
        }
        else
        {
            transform.position = lastAcceptedPosition;
        }
    }
}
